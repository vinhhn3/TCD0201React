const user = require('./user');
const origami = require('./origami');

module.exports = {
  user,
  origami
};